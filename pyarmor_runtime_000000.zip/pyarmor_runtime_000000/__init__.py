# Pyarmor 8.5.12 (trial), 000000, 2024-10-14T11:16:02.286255
from .pyarmor_runtime import __pyarmor__
